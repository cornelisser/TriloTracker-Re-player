#===================================================================
#
#	Frame Class
#	
#===================================================================
class Frame:
	
	def __init__(self,number,status):
		self.number 	= number
		self.status 	= status
		
		
