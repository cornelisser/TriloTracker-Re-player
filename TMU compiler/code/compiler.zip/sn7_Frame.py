#===================================================================
#
#	SN7_Frame Class
#	
#===================================================================
class SN7_Frame:
	
	def __init__(self,vol0,vol1,vol2,vol3,ton0,ton1,ton2,noi3):
		self.vol0		= vol0
		self.vol1		= vol1
		self.vol2		= vol2
		self.vol3		= vol3		
		self.ton0		= ton0
		self.ton1		= ton1
		self.ton2		= ton2
		self.noi3		= noi3			
	
		