#===================================================================
#
#	OPLL_Frame Class
#	
#===================================================================
class OPLL_Frame:	
	def __init__(self,reg0,reg1,reg2,reg3,reg4,reg5,reg6,reg7,regE,reg10,reg11,reg12,reg13,reg14,reg15,reg16,reg17,reg18,reg20,reg21,reg22,reg23,reg24,reg25,reg26,reg27,reg28,reg30,reg31,reg32,reg33,reg34,reg35,reg36,reg37,reg38):
		self.reg0		= reg0
		self.reg1		= reg1
		self.reg2		= reg2
		self.reg3		= reg3		
		self.reg4		= reg4
		self.reg5		= reg5
		self.reg6		= reg6
		self.reg7		= reg7			
		self.regE		= regE
		self.reg10		= reg10
		self.reg11		= reg11
		self.reg12		= reg12	
		self.reg13		= reg13
		self.reg14		= reg14	
		self.reg15		= reg15
		self.reg16		= reg16
		self.reg17		= reg17	
		self.reg18		= reg18
		self.reg10		= reg20
		self.reg11		= reg21
		self.reg12		= reg22	
		self.reg13		= reg23
		self.reg14		= reg24	
		self.reg15		= reg25
		self.reg16		= reg26
		self.reg17		= reg27	
		self.reg18		= reg28
		self.reg10		= reg30
		self.reg11		= reg31
		self.reg12		= reg32	
		self.reg13		= reg33
		self.reg14		= reg34	
		self.reg15		= reg35
		self.reg16		= reg36
		self.reg17		= reg37	
		self.reg18		= reg38