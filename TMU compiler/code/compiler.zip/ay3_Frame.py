#===================================================================
#
#	AY3_Frame Class
#	
#===================================================================
class AY3_Frame:
	
	def __init__(self,reg0,reg1,reg2,reg3,reg4,reg5,reg6,reg7,reg8,reg9,regA,regB,regC,regD):
		self.reg0		= reg0
		self.reg1		= reg1
		self.reg2		= reg2
		self.reg3		= reg3		
		self.reg4		= reg4
		self.reg5		= reg5
		self.reg6		= reg6
		self.reg7		= reg7			
		self.reg8		= reg8
		self.reg9		= reg9
		self.regA		= regA
		self.regB		= regB	
		self.regC		= regC
		self.regD		= regD	
		